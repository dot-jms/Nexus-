// ── BOOT ──
initAuth();
